
export default function SupportPage() {
  return (
    <div style={{ maxWidth: '640px', margin: '2rem auto', padding: '1rem' }}>
      <h1 style={{ fontSize: '2rem', fontWeight: 'bold', color: '#dc2626', textAlign: 'center' }}>Support FreedomX</h1>
      <p style={{ textAlign: 'center', fontSize: '1.1rem', marginTop: '1rem' }}>
        We are building Africa's most powerful delivery and logistics platform — by Africa, for Africa.
      </p>

      <div style={{ marginTop: '2rem', border: '1px solid #ccc', padding: '1rem', borderRadius: '0.5rem' }}>
        <h2 style={{ fontSize: '1.2rem', fontWeight: 'bold' }}>📄 Download Our Pitch Deck</h2>
        <p>Read our detailed loan request letter and expansion strategy.</p>
        <a href="/Ahmed_Hussein_FreedomX_Loan_Request_FIXED.pdf" target="_blank">
          <button style={{ marginTop: '0.5rem', padding: '0.5rem 1rem', border: '1px solid #000' }}>
            PDF: FreedomX_Loan_Request
          </button>
        </a>
      </div>

      <div style={{ marginTop: '2rem', border: '1px solid #ccc', padding: '1rem', borderRadius: '0.5rem' }}>
        <h2 style={{ fontSize: '1.2rem', fontWeight: 'bold', color: 'green' }}>💳 Contribute or Back Our Mission</h2>
        <p>
          Fund the launch of FreedomX — every dollar supports merchant onboarding, driver operations,
          and tech deployment across Somalia, Kenya, and beyond.
        </p>
        <p style={{ fontStyle: 'italic', fontSize: '0.9rem', color: '#666' }}>
          This is a support-based contribution only. No equity or shareholding is offered.
        </p>
        <div style={{ marginTop: '1rem' }}>
          <button style={{ display: 'block', width: '100%', backgroundColor: '#16a34a', color: 'white', padding: '0.75rem', marginBottom: '0.5rem' }}>
            Support via Stripe (Coming Soon)
          </button>
          <button style={{ display: 'block', width: '100%', backgroundColor: '#2563eb', color: 'white', padding: '0.75rem' }}>
            Support via Flutterwave (Coming Soon)
          </button>
        </div>
      </div>

      <p style={{ textAlign: 'center', fontSize: '0.85rem', color: '#666', marginTop: '2rem' }}>
        Contact: Ahmed Hussein Maow – naxariis111@gmail.com
      </p>
    </div>
  );
}
