
export default function Home() {
  return (
    <div style={{ minHeight: '100vh', display: 'flex', justifyContent: 'center', alignItems: 'center', flexDirection: 'column' }}>
      <h1 style={{ fontSize: '2rem', fontWeight: 'bold', color: '#dc2626' }}>Welcome to FreedomX Admin Dashboard</h1>
      <p style={{ marginTop: '1rem', fontSize: '1rem', maxWidth: '600px', textAlign: 'center' }}>
        This is the official backend control panel for managing restaurants, drivers, analytics, and more.
      </p>
      <p style={{ marginTop: '1rem', fontSize: '0.9rem', color: '#555' }}>
        Visit <a href="/support" style={{ color: '#2563eb', textDecoration: 'underline' }}>/support</a> to view our public fundraising page.
      </p>
    </div>
  );
}
