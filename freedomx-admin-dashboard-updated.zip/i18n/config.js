
module.exports = {
  locales: ["en", "es", "fr"],
  defaultLocale: "en",
};
