
const admin = require("firebase-admin");
admin.initializeApp();

async function seed() {
  const db = admin.firestore();

  const restaurants = [
    { id: 'r1', name: 'Pizza Palace', ownerEmail: 'owner1@example.com', region: 'North' },
    { id: 'r2', name: 'Taco Town', ownerEmail: 'owner2@example.com', region: 'South' },
  ];

  const drivers = [
    { id: 'd1', name: 'Alice', region: 'North' },
    { id: 'd2', name: 'Bob', region: 'South' },
  ];

  for (const r of restaurants) {
    await db.collection('restaurants').doc(r.id).set(r);
  }

  for (const d of drivers) {
    await db.collection('drivers').doc(d.id).set(d);
  }

  console.log("Seeded Firestore");
}

seed();
