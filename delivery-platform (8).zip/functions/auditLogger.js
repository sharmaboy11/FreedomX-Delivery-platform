
const functions = require("firebase-functions");
const admin = require("firebase-admin");

admin.initializeApp();

exports.logAudit = functions.https.onCall(async (data, context) => {
  const { event, details } = data;
  const user = context.auth?.uid || "unknown";

  await admin.firestore().collection('auditLogs').add({
    user,
    event,
    details,
    timestamp: admin.firestore.FieldValue.serverTimestamp()
  });

  return { success: true };
});
