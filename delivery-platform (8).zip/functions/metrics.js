
const functions = require("firebase-functions");

exports.metrics = functions.https.onRequest((req, res) => {
  res.set("Content-Type", "text/plain");
  res.send(`# HELP driver_deliveries Number of driver deliveries\n# TYPE driver_deliveries gauge\ndriver_deliveries 42`);
});
