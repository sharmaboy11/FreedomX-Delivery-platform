
const functions = require("firebase-functions");
const admin = require("firebase-admin");
const sgMail = require("@sendgrid/mail");
const { jsPDF } = require("jspdf");

sgMail.setApiKey(process.env.SENDGRID_API_KEY);

exports.sendWeeklyReports = functions.pubsub.schedule("every monday 09:00").onRun(async () => {
  const restaurants = await admin.firestore().collection("restaurants").get();

  for (const doc of restaurants.docs) {
    const data = doc.data();
    const docPdf = new jsPDF();
    docPdf.text(`Weekly Report for ${data.name}`, 10, 10);
    docPdf.text("This is a placeholder report.", 10, 20);

    const pdfBuffer = docPdf.output("arraybuffer");

    const msg = {
      to: data.ownerEmail,
      from: "reports@yourapp.com",
      subject: `Weekly Report - ${data.name}`,
      text: `Attached is the weekly performance report for ${data.name}.`,
      attachments: [
        {
          content: Buffer.from(pdfBuffer).toString("base64"),
          filename: "report.pdf",
          type: "application/pdf",
          disposition: "attachment",
        },
      ],
    };

    await sgMail.send(msg);
  }
});
