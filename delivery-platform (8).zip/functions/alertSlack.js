
const functions = require("firebase-functions");
const admin = require("firebase-admin");
const axios = require("axios");

exports.sendSlackAlert = functions.pubsub.schedule("every 24 hours").onRun(async () => {
  const drivers = await admin.firestore().collection('drivers').get();
  const lowPerformers = [];

  drivers.forEach(doc => {
    const data = doc.data();
    if (data.deliveries < 5) {
      lowPerformers.push(`${data.name}: ${data.deliveries} deliveries`);
    }
  });

  if (lowPerformers.length > 0) {
    await axios.post(process.env.SLACK_WEBHOOK_URL, {
      text: `🚨 Low Performing Drivers:
${lowPerformers.join('
')}`
    });
  }
});
