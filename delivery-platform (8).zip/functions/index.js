
const functions = require("firebase-functions");
const admin = require("firebase-admin");
admin.initializeApp();

exports.generateQRLoginToken = functions.https.onCall(async (data, context) => {
  const uid = data.uid;
  const token = `qr_${Date.now()}_${Math.floor(Math.random() * 1000)}`;
  await admin.firestore().collection('qr_tokens').doc(token).set({
    uid,
    createdAt: admin.firestore.FieldValue.serverTimestamp(),
    expiresIn: 300, // 5 min
  });
  return { token };
});

exports.checkQRLogin = functions.https.onCall(async (data) => {
  const token = data.token;
  const doc = await admin.firestore().collection('qr_tokens').doc(token).get();
  if (!doc.exists) return { success: false };
  return { success: true, uid: doc.data().uid };
});
