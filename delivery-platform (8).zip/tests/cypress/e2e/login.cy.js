
describe('Login flow', () => {
  it('Visits login and checks header', () => {
    cy.visit('/login');
    cy.contains('Log in');
  });
});
