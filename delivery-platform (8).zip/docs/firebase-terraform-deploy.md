
# Deploy Firebase Infrastructure with Terraform

## Prerequisites
- `gcloud` CLI authenticated
- Terraform installed
- Enable APIs: App Engine Admin API, Firestore API, Firebase API

## Steps

```bash
cd infra
terraform init
terraform apply -var="project_id=your-firebase-project-id"
```
