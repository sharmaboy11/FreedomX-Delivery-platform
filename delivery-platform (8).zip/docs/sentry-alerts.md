
# Sentry Alert Setup

1. Go to your Sentry project > Alerts > New Alert Rule
2. Conditions:
   - Event type: Error
   - Affected user count > 0
3. Actions:
   - Send Slack notification
   - Send email to engineering
4. Save the alert rule

Ensure you’ve set `NEXT_PUBLIC_SENTRY_DSN` in `.env.production`.
