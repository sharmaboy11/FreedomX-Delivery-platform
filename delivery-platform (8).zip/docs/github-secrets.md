
# GitHub Secrets for CI/CD

| Secret Name         | Description                              |
|---------------------|------------------------------------------|
| FIREBASE_TOKEN      | Firebase CI deploy token                 |
| SENDGRID_API_KEY    | API key for sending email reports        |
| SLACK_WEBHOOK_URL   | Webhook for sending Slack alerts         |
| CLERK_API_KEY       | Clerk secret API key                     |
| CLERK_FRONTEND_API  | Clerk frontend key                       |

Set these in your repo under **Settings > Secrets and variables > Actions**.
