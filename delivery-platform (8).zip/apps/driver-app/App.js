
import React from 'react';
import { View, Text, Button } from 'react-native';
import * as Linking from 'expo-linking';

export default function App() {
  const handleScan = () => {
    // Simulate QR scan
    alert("Scanned QR! Logging in...");
  };

  return (
    <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
      <Text>Driver App</Text>
      <Button title="Scan QR to Login" onPress={handleScan} />
    </View>
  );
}
