
'use client';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip } from 'recharts';

const data = [
  { name: 'Driver A', deliveries: 14 },
  { name: 'Driver B', deliveries: 22 },
  { name: 'Driver C', deliveries: 18 },
];

export default function DriverStats() {
  return (
    <BarChart width={500} height={300} data={data}>
      <CartesianGrid stroke="#ccc" />
      <XAxis dataKey="name" />
      <YAxis />
      <Tooltip />
      <Bar dataKey="deliveries" fill="#82ca9d" />
    </BarChart>
  );
}
