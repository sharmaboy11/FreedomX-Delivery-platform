
'use client';
import { useState } from 'react';

export default function FranchiseFilter({ onSelect }) {
  const [selected, setSelected] = useState('All');

  const handleChange = (e) => {
    setSelected(e.target.value);
    onSelect(e.target.value);
  };

  return (
    <select onChange={handleChange} value={selected} className="border p-2 mb-4">
      <option>All</option>
      <option>North</option>
      <option>South</option>
    </select>
  );
}
