
'use client';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip } from 'recharts';

const data = [
  { name: 'Mon', deliveries: 24 },
  { name: 'Tue', deliveries: 18 },
  { name: 'Wed', deliveries: 32 },
  { name: 'Thu', deliveries: 12 },
  { name: 'Fri', deliveries: 44 },
];

export default function Chart() {
  return (
    <LineChart width={500} height={300} data={data}>
      <XAxis dataKey="name" />
      <YAxis />
      <CartesianGrid stroke="#ccc" />
      <Tooltip />
      <Line type="monotone" dataKey="deliveries" stroke="#8884d8" />
    </LineChart>
  );
}
