
import { useEffect, useState } from 'react';
import { onSnapshot, collection } from 'firebase/firestore';
import { db } from '@/firebase';

export default function useLiveDriverData() {
  const [data, setData] = useState([]);

  useEffect(() => {
    const unsub = onSnapshot(collection(db, 'drivers'), (snapshot) => {
      const newData = snapshot.docs.map(doc => ({ ...doc.data(), id: doc.id }));
      setData(newData);
    });

    return () => unsub();
  }, []);

  return data;
}
