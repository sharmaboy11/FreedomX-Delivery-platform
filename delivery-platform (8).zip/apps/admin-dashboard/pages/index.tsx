
import React from 'react';
import dynamic from 'next/dynamic';

const Chart = dynamic(() => import('@/components/Chart'), { ssr: false });
const DriverStats = dynamic(() => import('@/components/DriverStats'), { ssr: false });

export default function Dashboard() {
  return (
    <div className="p-8">
      <h1 className="text-2xl font-bold mb-4">Admin Dashboard</h1>
      <Chart />
      <div className="mt-8" />
      <DriverStats />
    </div>
  );
}
