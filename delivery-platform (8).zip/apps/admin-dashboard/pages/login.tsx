
export default function Login() {
  return (
    <div className="p-8">
      <h1 className="text-xl mb-4">Login</h1>
      <input placeholder="Email" className="border p-2 mb-2 block" />
      <input placeholder="Password" type="password" className="border p-2 mb-4 block" />
      <button className="bg-blue-500 text-white p-2 rounded">Login</button>
    </div>
  );
}
